from datetime import datetime
from pydantic import BaseModel, Field, validator
from enum import Enum


class BookingStatus(str, Enum):
    PENDING = "pending"
    CONFIRMED = "confirmed"
    CANCELLED = "cancelled"
    COMPLETED = "completed"
    EXPIRED = "expired"


class BookingCreate(BaseModel):
    user_id: int = Field(..., gt=0, description="ID пользователя")
    spot_id: int = Field(..., gt=0, description="ID парковочного места")
    start_time: datetime = Field(..., description="Начало бронирования")
    end_time: datetime = Field(..., description="Конец бронирования")
    notes: str = Field(None, max_length=500, description="Заметки")

    @validator('end_time')
    def end_time_after_start(cls, v, values):
        if 'start_time' in values and v <= values['start_time']:
            raise ValueError('end_time должен быть позже start_time')
        return v


class BookingUpdate(BaseModel):
    status: BookingStatus = Field(None, description="Новый статус")
    notes: str = Field(None, max_length=500)
    cancellation_reason: str = Field(None, max_length=500, description="Причина отмены")


class BookingRead(BaseModel):
    id: int
    user_id: int
    spot_id: int
    start_time: datetime
    end_time: datetime
    status: BookingStatus
    created_at: datetime
    updated_at: datetime
    notes: str = None
    cancellation_reason: str = None

    class Config:
        from_attributes = True


class BookingListResponse(BaseModel):
    bookings: list[BookingRead]
    total: int
    page: int
    size: int
    pages: int


class AvailableSpotInfo(BaseModel):
    spot_id: int
    parking_id: int
    spot_number: int
    spot_type: str
    coordinates: dict = None
    available_from: datetime = None
    available_until: datetime = None


class BookingConflict(BaseModel):
    spot_id: int
    conflicts: list[BookingRead]